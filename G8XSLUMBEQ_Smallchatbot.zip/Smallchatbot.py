response = {
    "hi": "Hello! Karthik",
    "what is learning today" : "Today learning new concept javascript",
    "how many hours Practice" : "today your 3 hours practice and 2 hours class",
    "break fast timing" : "9:00 am to 9:35am",
    "Lunch timing" : "12:00pm to 1:00pm",
    "break" : "every class 5minutes"
}

user_input = input()

for char in response:
    if (user_input == char):
        Chatbot_response = response[char]
print(Chatbot_response)